import os.path
from nltk.tokenize import word_tokenize
import re
import pathlib




class Main(object):



    regex = re.compile('[^a-zA-Z]')

    folders = os.listdir("C:/Users/Rafael/Desktop/grupos/Reuters10/")

    #open groups

    for f in folders:

        endereceGrupo = "C:/Users/Rafael/Desktop/grupos/Reuters10/" + f +"/"

        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/acq/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/corn/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/crude/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/earn/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/grain/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/interest/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/money-fx/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/ship/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/trade/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/Reuters10/" + f + "/webkb/wheat/") \
            .mkdir(parents=True, exist_ok=True)


        groups = []
        for filename in os.listdir(endereceGrupo):
            file = open(endereceGrupo + filename, "r")
            texto = file.read()
            tokensGroups = word_tokenize(texto)
            groups.append(tokensGroups)


        endereco = "C:/Users/Rafael/Desktop/data/Reuters10/"

        directories = os.listdir(endereco)

        for i in directories:
            for filename in os.listdir(endereco + i):
                link = endereco + i + "/" + filename
                print(link)
                file = open(link, "r")
                t = regex.sub(' ', file.read())
                texto = t.lower()
                tokens = word_tokenize(texto)

                listText = ""

                for t in tokens:
                    for g in groups:
                        if t in g:
                            listText = listText + " " + g[0]
                            break


                newText = open("C:/Users/Rafael/Desktop/output/Reuters10/" + f +"/" + filename, "w")
                newText.write(listText)
                newText.close()



