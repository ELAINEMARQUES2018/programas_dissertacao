import os.path
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn.cluster import MeanShift, estimate_bandwidth
from sklearn.cluster import Birch
from sklearn.cluster import AgglomerativeClustering
import numpy as np
import pathlib

class Agrupamento(object):

    def __init__(self):
        self.path = os.path.dirname(__file__)

    def kMeans(self, vetorSimilaridades, valor_k):
        x = np.array(vetorSimilaridades)
        kmeans = KMeans(n_clusters=valor_k, random_state=0).fit(x)
        result = kmeans.predict(x)
        return result

    def DBSCAN(self, vetorSimilaridades):
        x = np.array(vetorSimilaridades)
        db = DBSCAN(eps=0.2, min_samples=5).fit(x)
        core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
        core_samples_mask[db.core_sample_indices_] = True
        result = db.labels_
        return result

    def MeanShift(self, vetorSimilaridades):
        x = np.array(vetorSimilaridades)
        bandwidth = estimate_bandwidth(x, quantile=0.2, n_samples=None)
        ms = MeanShift(bandwidth=bandwidth, big_seeding=True)
        ms.fit(x)
        result = ms.labels_
        return result

    def Birch(self, vetorSimilaridades, valor_k):
        x = np.array(vetorSimilaridades)
        birch_models = Birch(n_clusters=valor_k, threshold=1.7).fit(x)
        result = birch_models.predict(x)
        return result

    def AgglomerativeClustering(self, vetorSimilaridades, valor_k):
        x = np.array(vetorSimilaridades)
        for linkage in ('ward', 'average', 'complete'):
            ac = AgglomerativeClustering(linkage=linkage, n_clusters=valor_k)
            ac.fit(x)
            result = ac.labels_
            return result

    def salvarAgrupamento(self, saveDiretory, resultadoCluster, tokens):

        pathlib.Path(saveDiretory) \
            .mkdir(parents=True, exist_ok=True)

        k = len(resultadoCluster)

        for index in range(k):
            arquivo = open(os.path.join(self.path, saveDiretory  + 'grupo_'+str(index+1)),'w')
            texto = ""
            for index2 in range(k):
               if index == resultadoCluster[index2]:
                   texto += tokens[index2] + "\n"
            arquivo.write(texto)
            arquivo.close()

