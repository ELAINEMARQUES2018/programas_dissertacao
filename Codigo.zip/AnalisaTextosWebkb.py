import os.path
from nltk.tokenize import word_tokenize
import re
import pathlib




class Main(object):



    regex = re.compile('[^a-zA-Z]')

   # newsgroup20kValues = [3631, 7263, 10893]
    webkbValues = [2741, 5482, 8223, 10964, 13705, 16446, 18187, 21928]

    #open groups

    for value in webkbValues:

        endereceGrupo = "C:/Users/Rafael/Desktop/grupos/webkb/" + str(value) +"/"

        pathlib.Path("C:/Users/Rafael/Desktop/output/webkb/" + str(value) + "/webkb/course/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/webkb/" + str(value) + "/webkb/faculty/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/webkb/" + str(value) + "/webkb/project/") \
            .mkdir(parents=True, exist_ok=True)
        pathlib.Path("C:/Users/Rafael/Desktop/output/webkb/" + str(value) + "/webkb/student/") \
            .mkdir(parents=True, exist_ok=True)

        groups = []
        for filename in os.listdir(endereceGrupo):
            file = open(endereceGrupo + filename, "r")
            texto = file.read()
            tokensGroups = word_tokenize(texto)
            groups.append(tokensGroups)


        endereco = "webkb/"

        directories = os.listdir(endereco)

        for i in directories:
            for filename in os.listdir(endereco + i):
                link = endereco + i + "/" + filename
                print(link)
                file = open(link, "r")
                t = regex.sub(' ', file.read())
                texto = t.lower()
                tokens = word_tokenize(texto)

                listText = ""

                for t in tokens:
                    for g in groups:
                        if t in g:
                            listText = listText + " " + g[0]
                            break


                newText = open("C:/Users/Rafael/Desktop/output/webkb/" + str(value) +"/" + link, "w")
                newText.write(listText)
                newText.close()



