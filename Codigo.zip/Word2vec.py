import os.path
from gensim.models import word2vec

class Word2vec(object):

    def __init__(self):
        self.path = os.path.dirname(__file__)

    def treinarWord2vec(self, texto, nomeDoModel):
        logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
        sentences = word2vec.Text8Corpus(os.path.join(self.path,texto))
        #Esse trecho é usado para treinar o word2vec
        model = word2vec.Word2Vec(sentences, size=10, window=5, min_count=5, workers=4)
        #Esse trecho é usado para salvar o modelo treinado
        model.save(os.path.join(self.path,nomeDoModel))

    def carregarWord2vec(self, endereco):
        model = word2vec.Word2Vec.load(os.path.join(self.path,endereco))
        return model