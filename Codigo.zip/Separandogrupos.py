import os.path


class Separandogrupos(object):
    def __init__(self):
        self.path = os.path.dirname(__file__)

    def grupoBase(self, vetor):
        arquivoBase = open('text8', 'r')
        # print(arquivoBase.read())
        # Se essa parte abriu corretamente comenta o read para poder ler o split

        vetor = arquivoBase.read().split()
        # print('Mostrando o que tem no split')
        # print(vetor)

    def grupoDoc(self, palavrasGrupo):
        path = os.path.dirname(__file__)

        #print('\nMostrando o caminho da pasta atual')
        #print(path)

        # concatena o diretorio com o nome onde se encontra os arquivos
        cmDoc = path + '\\entrada'

        # print('\nNo entanto a pasta onde estao os arquivos nao e essa entao e preciso adcionar o nome da pasta onde esta o arquivo e ficará assim:')
        #print(cmDoc)

        # pega o nome de todos os arquivos no diretorio selecionado
        dirsDocs = os.listdir(cmDoc)

        #print('\nApos chamar a funcao que pega todos os arquivos vamos verificar se ele fez corretamente')
        # imprime o nome dos arquivos na tela
        #print(dirsDocs)


        ####################
        # concatena o diretorio com o nome onde se encontra os arquivos
        cmGrp = path + '\\grupo'
        #print(cmGrp)

        # pega o nome de todos os arquivos no diretorio selecionado
        dirsGp = os.listdir(cmGrp)

        # imprime o nome dos arquivos na tela
        #print(dirsGp)

        cont = 0

        for aux in dirsDocs:

            if cont > 99:
                break
            cont += 1

            caminhoDocs = cmDoc + '\\' + aux
            documento = open(caminhoDocs, "r")
            palavrasDocs = documento.read().split()
            teste = False

            for palavraDc in palavrasDocs:

                for atual in dirsGp:

                    caminhoGrup = cmGrp + '\\' + atual
                    grupo = open(caminhoGrup, "r")
                    palavrasGrupo = grupo.read().split()

                    for pesquisa in palavrasGrupo:
                        if (palavraDc == pesquisa):
                            teste = True
                            print("A palavra: " + pesquisa + " do documento: " + aux + " esta no grupo: " + atual)
                            break
                            # if(teste == True):
                            # break