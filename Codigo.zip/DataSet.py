import os.path
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

class DataSet(object):



    def __init__(self):
        self.path = os.path.dirname(__file__)

    def getDataSet(self, endereco, directories):

        regex = re.compile('[^a-zA-Z]')


        texto = ""

        #file = open("20ng-train-no-stop.txt", "r")
        #t = regex.sub(' ', file.read())
        #texto = t.lower()

        #tokens = word_tokenize(texto)
        #myset = set(tokens)
        #mynewlist = list(myset)
        #filtered_words = [word for word in mynewlist if word not in stopwords.words('english')]


        for i in directories:
          for filename in os.listdir(endereco + i):
              if (filename not in ".DS_Store"):
                  link = endereco + i + "/" + filename
                  print(link)
                  file = open(link, "r")
                  t = regex.sub(' ', file.read())
                  texto = texto + t.lower()

        tokens = word_tokenize(texto)
        myset = set(tokens)
        mynewlist = list(myset)
        filtered_words = [word for word in mynewlist if word not in stopwords.words('english')]

        return filtered_words



