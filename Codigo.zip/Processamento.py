import os.path
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
#from Word2vec import *
from gensim.models import KeyedVectors
from gensim.test.utils import datapath, get_tmpfile
from gensim.scripts.glove2word2vec import glove2word2vec


class Processamento(object):
    def __init__(self):
        self.path = os.path.dirname(__file__)

    def removerStopWords(self, text):
        stop_words = stopwords.words('english')
        caracteresEspeciais = ["'", ",", ".", ";", ":", "!", "?", "@", "#", "$", "%", "&", "*", "=", "}", "{", "(", ")",
                               "<", ">", "/", "\\", "+", '"', "\n", "\t"]
        tokens = word_tokenize(text.lower())
        txtFinal = []

        for item in tokens:
            if item not in stop_words and item not in caracteresEspeciais:
                txtFinal += [item]

        return txtFinal

    def criarVetorSimilaridades(self, text):
       # Wvec = Word2vec()
      #  model = Wvec.carregarWord2vec("text8.model")
        print("carredando modelo")
        model = KeyedVectors.load_word2vec_format('vectors-SLIM.bin', binary=True)
        print("Carregado")
        vetorSimilaridades = []

        for index in range(len(text)):
            vetorTemp = []
            for index2 in range(len(text)):
                try:
                    if index != index2:
                        vetorTemp += [model.wv.similarity(text[index], text[index2])]
                    else:
                        vetorTemp += [1]
                except:
                    vetorTemp += [0]
            vetorSimilaridades += [vetorTemp]
            print("gerando vetor " + str(index))
            # print(vetorSimilaridades)

        return vetorSimilaridades

    def criarVetorSimilaridadesGlove(self, text):
        # Wvec = Word2vec()
        #  model = Wvec.carregarWord2vec("text8.model
        print("carredando modelo")
        model = KeyedVectors.load_word2vec_format("glove.w2vformat", binary=True)
        print("Carregado")
        vetorSimilaridades = []

        for index in range(len(text)):
            vetorTemp = []
            for index2 in range(len(text)):
                try:
                    if index != index2:
                        vetorTemp += [model.wv.similarity(text[index], text[index2])]
                    else:
                        vetorTemp += [1]
                except:
                    vetorTemp += [0]
            vetorSimilaridades += [vetorTemp]
            print("gerando vetor " + str(index))
            # print(vetorSimilaridades)

        return vetorSimilaridades

    def criarVetorCaracteristica(self, text):
       # Wvec = Word2vec()
      #  model = Wvec.carregarWord2vec("text8.model")
       print("carredando modelo")
       model = KeyedVectors.load_word2vec_format('vectors.bin', binary=True)
       print("Carregado")
       vetorCaracteristicas = []

       for t in text:
            try:
                vetorCaracteristicas.append(model.word_vec(t))
                print("gerando vetor " + t)
            except:
                print("nao tem o vetor " + t)


       return vetorCaracteristicas