import os.path

class verificacao(object):

    def __init__(self):
        self.path = os.path.dirname(__file__)

    def leituraBase(self,vetor):
        arquivoBase = open('text8','r')
        #print(arquivoBase.read())
        #Se essa parte abriu corretamente comenta o read para poder ler o split

        vetor = arquivoBase.read().split()
        #print('Mostrando o que tem no split')
        #print(vetor)

    def leituraArquivos(self,novovetor):
        path = os.path.dirname(__file__)

        #print('\nMostrando o caminho da pasta atual')
        #print(path)

        #concatena o diretorio com o nome onde se encontra os arquivos
        path = path + '\\entrada'

        #print('\nNo entanto a pasta onde estao os arquivos nao e essa entao e preciso adcionar o nome da pasta onde esta o arquivo e ficarar assim:')
        #print(path)

        #pega o nome de todos os arquivos no diretorio selecionado
        dirs = os.listdir(path)

        #print('\nApos chamar a funcao que pega todos os arquivos vamos verificar se ele fez corretamente')
        #imprime o nome dos arquivos na tela
        #print(dirs)
        #quanto = len(dirs) #imprime o nome dos 3000 documentos existente na pasta
        #print(quanto)

        #iniciando o vetor final que ira conter as palavras encontradas
        txtfinal = []
        #print('\ntxtfinal esta vazio mesmo? vamos ver')
        #print(txtfinal)

        cont = 0

        escritaPalavras = []

        for atual in dirs:
            #print('\nEntrou no for e cont agora vale:')
            #print(cont)

            if cont > 0:
                #print('cont chegou a 100, entao para')
                break
            cont +=1

            #print('\nEu sei o caminho do arquivo e o for pegou o nome de um arquivo agora qual foi:')
            #print(atual)

            #print('\nEntao vamos juntar para abrir o arquivo')
            #formando o caminho do arquivo para abertura
            caminho = path + '\\' + atual
            # abertura do arquivo atual
            #print('\nVamos verificar se ele juntou certo para abrir o arquivo')
            #print(caminho)

            arquivo = open(caminho, "r")
            #print('\n Sera que deu erro na abertura do arquivo?\n vamos ver o conteudo\n\n')
            #print(arquivo.read())

            palavras = arquivo.read().split()
            #print('\n Nessa parte ele separa as palavras, vamos ver')
            #print(palavras)


            for pesquisa in palavras:
                #print('\n Qual a palavra que eu quero saber se esta na base?')
                #print(pesquisa)

                for palavra in novovetor:
                    #print('\n Vou comparar se e igual a essa palavra que esta na base')
                    #print(palavra)
                    #print("\nPalavra: "+palavra+" Pesquisa: "+pesquisa)

                    if pesquisa == palavra:
                        #print('\n Sao iguais!!!! entao vamos adicionar no vetor txtfinal')
                        txtfinal +=[palavra]
                        escritaPalavras += [palavra]
                        #print("\nPalavra: " + palavra + " esta no documento(grupo): " + atual)
                        break
                        #print('\n Vamos ver quais as palavras que ele ja adicionou')
                        #print(txtfinal)

            arquivo.close()
            arquivo = open(caminho, "w")

            for palavra in escritaPalavras:
                arquivo.write(palavra + "\n")

            arquivo.close()

        print('Palavras encontradas')
        print(txtfinal)
        print('aqui')
        print(escritaPalavras)
        print('fim leitura arquivos')




