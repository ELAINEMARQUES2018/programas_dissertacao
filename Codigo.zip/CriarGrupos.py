from Processamento import *
from DataSet import *
from Agrupamento import *



class Main(object):
    process = Processamento()
    bd = DataSet()
    agrup = Agrupamento()

    newsgroup20 = ["alt.atheism", "comp.graphics", "comp.os.ms-windows.misc", "comp.sys.ibm.pc.hardware",
                   "comp.sys.mac.hardware", "comp.windows.x", "misc.forsale", "rec.autos", "rec.motorcycles",
                   "rec.sport.baseball", "rec.sport.hockey", "sci.crypt", "sci.electronics", "sci.med", "sci.space",
                   "soc.religion.christian", "talk.politics.guns", "talk.politics.mideast",
                   "talk.politics.misc", "talk.religion.misc"]

    webkb = ["student", "course", "project", "faculty"]

    Reuters10 = ["acq", "corn", "crude", "earn", "grain", "interest", "money-fx", "ship", "trade",
                   "wheat"]

    #Valores variando de 50% a 5% com variacao de 5 em 5 0.5, 0.45, 0.4, 0.35, 0.30, 0.25, 0.2, 0.15, 0.1,
    #newsgroup20kValues = [3631,7263,10893,14524,18155,21786,25417,29048]

    #webkbValues = [2741, 5482, 8223, 10964, 13705, 16446, 18187, 21928]

    reutersValues = [8088]

    diretory = "/Users/rafaelfmello/PycharmProjects/MestradoElaine/data/Reuters10/"

    baseDados = bd.getDataSet(diretory,Reuters10)
    print("data ok")
    print (len(baseDados))


    vetorSimilaridades = process.criarVetorSimilaridades(baseDados)


#    resultadoAgrupamento = agrup.MeanShift(vetorSimilaridades)
#    agrup.salvarAgrupamento("C:/Users/Rafael/Desktop/grupos/Reuters10/glove-MeanShift-/", resultadoAgrupamento, baseDados)


    for k in reutersValues:
        print (k)
        resultadoAgrupamento = agrup.Birch(vetorSimilaridades, k)
        agrup.salvarAgrupamento("/Users/rafaelfmello/PycharmProjects/MestradoElaine/grupos/Reuters10/word2vec-Birch-" + str(k) + "/", resultadoAgrupamento, baseDados)



